const { Schema } = require('mongoose');
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
const url = "mongodb://localhost:27017/Hoopla_DB"

const usersSchema = Schema({
    userId : {type : String, required : [true, 'userId is required']},
    uCredentials : {
        uEmail : {type : String, required : [true, 'uMail is required']},
        uPass  : {type : String, required : [true, 'uPass is required']}
    },
    uProfile : {
        uName : {type : String, required : [true, 'uName is required']},
        uDOB : {type : Date, required : [true, 'uDOB is required']},
        uPhone : {type : Number, required : [true, 'uPhone is required']},
        uDateJoined : {type : Date, default : new Date().toISOString()},
        uLastLogin : {type : Date, default : new Date().toISOString()}
    }
}, {collection : "Users", timestamps: true })

const productsSchema = Schema({

    _id: {type : String, required : [true, '_id is required']} ,
    pName: {type : String, required : [true, 'pName is required']},
    pDescription: {type : String},
    pRating: {type : Number},
    pCategory:{type : String, required : [true, 'pCategory is required']},
    price: {type : Number, required : [true, 'price is required']},
    color: {type : String, required : [true, 'color is required']},
    image: {type : String, required : [true, 'image is required']},
    specification: {type : String},
    dateFirstAvailable:{type : Date, required : [true, 'dateFirstAvailable is required']},
    dateLastAvailable:{type : Date, required : [true, 'dateFirstAvailable is required']},
    pSeller: 
    {
        s_Id: {type : String, required : [true, 's_Id is required']},
        pDiscount:{type : Number},
        pQuantity:{type : Number, required : [true, 'pQuantity is required']},
        pShippingCharges: {type : Number, required : [true, 'pShippingCharges is required']}
    }
}, {collection : "Products", timestamps: true })


let connection = {}

//Returns model object of "Users" collection
connection.getCollection = () => {
    //establish connection and return model as promise
    return mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex : true}).then( database => {
        return database.model('Users', usersSchema)
    }).catch( error => {
        let err = new Error("Could not connect to the database");
        err.status = 500;
        throw err;
    });
}
//Returns model object of "Products" collection
connection.productCollection = () => {
    //establish connection and return model as promise
    return mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex : true}).then( database => {
        return database.model('Products', productsSchema)
    }).catch( error => {
        let err = new Error("Could not connect to the database");
        err.status = 500;
        throw err;
    });
}

module.exports = connection;