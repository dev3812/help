const collection = require('../utilities/connection');
const userData = require('./User.json');
let user = {}

//Setup the database
user.setupDB = () => {
   return collection.getCollection().then( userColl => {
       return userColl.deleteMany().then( data => {
           return userColl.insertMany(userData).then( result => {
               if( result && result.length > 0 ) return result.length
               else return null
           });
       });
   });
}
//Check for Email id
user.checkEmailId = (req,res,next) => {
    return collection.getCollection().then( userColl => {
        return userColl.findOne({"uCredentials.uEmail" : req.body.uEmail}).then( data => {
            if(data)
            {
                next(new Error("Email Id already exists!")); 
            }
            next()
        })
    }) 
    
}

//Generate UserId   
user.generateId = () => {
    return collection.getCollection().then((users) => {
        return users.distinct("userId").then((ids) => {
            let uId = ids.map(id =>Number(id.slice(1,)))
            uId = Math.max(...uId);
            return `U${uId + 1}`;
        })
    })
}
//Verify the user credentials and modify the last logout
user.userLogin = (uEmail,uPass) => {
    return collection.getCollection().then( userColl => {
        return userColl.findOne({"uCredentials.uEmail" : uEmail}).then( data => {
            if(data){
                if( uPass == data['uCredentials']['uPass']){
                    return userColl.updateOne({"uCredentials.uEmail":uEmail},{$set:{"uProfile.uLastLogin":new Date().toISOString()}}).then( res => {
                        if(res.nModified === 1){
                            return data
                        }
                    })
                }else{
                    throw new Error("The password entered is incorrect!!")
                }
            }else{
                throw new Error("You are not registered.Please register to login"); 
            }
        })
    }) 
    
}

user.registerUser = (userDetails) => {
    return collection.getCollection().then( UserColl => {
        return user.generateId().then(newId =>{
            userDetails.userId =newId;
            let newUser = new UserColl(userDetails)
            return newUser.save()
        })
    }) 
    
}

module.exports = user