const express = require("express");
const productRouting = express.Router();
const productService = require('../service/products');
const product = require("../model/Products");

productRouting.get('/getProducts/:category', (req,res,next)=>
{
    let category= req.params.category
    return productService.getProductsByCategory(category).then(products => {
        res.json(products);
    }).catch(err => {
        next(err);
    });
});

productRouting.get('/getAllProductCategories', (req,res,next)=>
{
    return productService.getAllProductCategories().then(categories => {
        res.json(categories);
    }).catch(err => {
        next(err);
    });
});

productRouting.get('/search/:parameter',(req,res,next)=>
{
    let fetch= req.params.parameter
    return productService.searchProduct(fetch).then(products => {
        res.json(products);
    }).catch(err => {
        next(err);
    });
})
productRouting.get('/productDetails/:parameter',(req,res,next)=>
{
    let fetch= req.params.parameter
    return productService.productdetails(fetch).then(productDetails => {
        res.json(productDetails);
    }).catch(err => {
        next(err);
    });
})

module.exports = productRouting
