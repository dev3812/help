import React, { Component } from "react";
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import FormControl from '@material-ui/core/FormControl';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import withStyles from '@material-ui/core/styles/withStyles';
import axios from "axios";

const usersBackendURL = "http://localhost:2000";

const styles = theme => ({
  main: {
    width: 'auto',
    display: 'block', // Fix IE 11 issue.
    marginLeft: theme.spacing(3),
    marginRight: theme.spacing(3),
    [theme.breakpoints.up(400 + theme.spacing(3) * 2)]: {
      width: 400,
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing(0),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: `${theme.spacing(2)}px ${theme.spacing(3)}px ${theme.spacing(3)}px`,
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    marginTop: theme.spacing(3),
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
  },
});

class RegisterComponent extends Component {
  state = {
    form: {
      uEmail: "",
      uPass: "",
      uName: "",
      uDOB: "",
      uPhone: ""
    },
    formErrMsg: {
      uEmail: "",
      uPass: "",
      uName: "",
      uDOB: "",
      uPhone: ""
    },
    formValid: {
      uEmail: false,
      uPass: false,
      uName: false,
      uDOB: false,
      uPhone: false,
      buttonActive: false
    },
    successResponse: "",
    errorMessage: ""
  }


  handleInputChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ form: { ...this.state.form, [name]: value } }, () => {
      console.log(this.state.form)
    });
    this.validateField(name, value);
  }

  validateField = (fieldName, value) => {
    var message;
    var { formErrMsg } = this.state;
    var { formValid } = this.state;

    switch (fieldName) {
      case 'uEmail':
        let emailRegex = new RegExp(/^[A-z][A-z0-9.]+@[a-z]+\.[a-z]{2,3}$/);
        value === "" ? message = "Required Feild" : emailRegex.test(value) ? message = "" : message = "Email id format is wrong"
        break;

      case "uPass":
        let passRegex = new RegExp(/^(?=.*[A-Z])(?=.*[!@#$&*%&])(?=.*[0-9])(?=.*[a-z]).{7,20}$/);
        value === "" ? message = "Required Feild" : passRegex.test(value) ? message = "" : message = "Invalid password"
        break
      case 'uPhone':
        value === '' ? message = 'Required Feild' : value.match(/^[0-9]{10}$/) ? message = "" : message = "Invalid phone number"
        break
      case 'uName':
        value === '' ? message = 'Required Feild' : value.match(/^[a-zA-z]+([\s][a-zA-Z]+)*$/) ? message = "" : message = "Invalid username"
        break
      case 'uDOB':
        if (value.length !== 0) {
          let today = new Date()
          let DOB = new Date(value)
          today.setHours(0, 0, 0, 0);
          DOB.setHours(0, 0, 0, 0);

          if (DOB >= today) {
            message = 'your DOB can\'t be today\'s date or greater'
          }
          else {
            message = ''

          }
        }
        else {
          message = 'Required Feild'
        } break

      default:
        break;
    }
    //Form err message set
    formErrMsg[fieldName] = message;
    this.setState({ formErrMsg: formErrMsg });
    //Form Valid set
    message === "" ? formValid[fieldName] = true : formValid[fieldName] = false;
    formValid.buttonActive = formValid.uEmail && formValid.uPass && formValid.uPhone && formValid.uName && formValid.uDOB;
    this.setState({ formValid: formValid });
  }

  register = (e) => {
    e.preventDefault();
    axios.post(`${usersBackendURL}/register`, this.state.form)
      .then(response => {
        console.log(response.data)
        this.setState({ successResponse: response.data,errorMessage:null })
      })
      .catch(error => {
        this.setState({ errorMessage: error.response ? error.response.data.message : error.message,successResponse:null })
      })
  }

  render() {
    const { uEmail, uPass, uDOB, uName, uPhone } = this.state.form;
    const { formErrMsg } = this.state
    const { classes } = this.props;

    return (
      <React.Fragment>
        <br></br><br></br>
        <div className="col-md-4 offset-4">
          <main className={classes.main}>
            <CssBaseline />
            <Paper className={classes.paper}>
              <Avatar className={classes.avatar}>
                <LockOutlinedIcon />
              </Avatar>
              <Typography component="h1" variant="h5">
                Create account
              </Typography>

              <form className={classes.form} id="form" onSubmit={this.register} >

                <FormControl margin="normal" required fullWidth>
                  <InputLabel htmlFor="uName">Username</InputLabel>
                  <Input
                    autoComplete="text"
                    autoFocus
                    id="uName"
                    name="uName"
                    value={uName}
                    onChange={this.handleInputChange} />
                  <span className="text-danger">{formErrMsg.uName}</span>
                </FormControl>

                <FormControl margin="normal" fullWidth>
                  <TextField
                    id="uDOB"
                    name="uDOB"
                    label="DOB"
                    type="date"
                    value={uDOB}
                    onChange={this.handleInputChange}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <span className="text-danger">{formErrMsg.uDOB}</span>
                </FormControl>

                <FormControl margin="normal" required fullWidth>
                  <InputLabel htmlFor="uPhone">Mobile Number</InputLabel>
                  <Input
                    autoComplete="date"
                    id="uPhone"
                    name="uPhone"
                    value={uPhone}
                    onChange={this.handleInputChange} />
                  <span className="text-danger">{formErrMsg.uPhone}</span>
                </FormControl>


                <FormControl margin="normal" required fullWidth>
                  <InputLabel htmlFor="uEmail">Email address</InputLabel>
                  <Input
                    autoComplete="email"
                    id="uEmail"
                    name="uEmail"
                    value={uEmail}
                    onChange={this.handleInputChange} />
                  <span className="text-danger">{formErrMsg.uEmail}</span>
                </FormControl>

                <FormControl margin="normal" required fullWidth>
                  <InputLabel htmlFor="uPass">Password</InputLabel>
                  <Input
                    name="uPass"
                    type="password"
                    value={uPass}
                    onChange={this.handleInputChange}
                    id="uPass"
                    autoComplete="current-password" />
                  <span className="text-danger">{formErrMsg.uPass}</span><br />
                </FormControl>

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  className={classes.submit}
                  disabled={!this.state.formValid.buttonActive}
                >Register
              </Button>

              </form><br />
              {this.state.errorMessage ? (<div className={'text-danger'}>{this.state.errorMessage}</div>) :
                this.state.successResponse && <div className="text-success">Successfully Registered</div>}
            </Paper>
          </main>
        </div>
      </React.Fragment>
    )
  }
}

export default withStyles(styles)(RegisterComponent)