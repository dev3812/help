import React, { Component } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import withStyles from '@material-ui/core/styles/withStyles';
import ViewProducts from './ViewProducts'
import axios from "axios";
import 'react-animated-slider/build/horizontal.css';
import CarouselPage from './Carousel';

const backendUrl = 'http://localhost:2000/product/getAllProductCategories'
const styles = theme => ({
    root: {
        flexGrow: 1,
        width: '100%',
        backgroundColor: theme.palette.background.paper,
        outline:"none"
      },   
})
class Category extends Component {
    constructor(props) {
        super(props)
        this.state = {
            value: -1,
            errorMessage: '',
            categories: [],
        }
    }
    handleChange = (event, newValue) => {
        this.setState({ value: newValue })
    };
    componentDidMount() {
        axios.get(backendUrl)
            .then(response => {
                this.setState({ categories: response.data, errorMessage: null })
            })
            .catch(error => {
                this.setState({ errorMessage: error.response ? error.response.data.message : error.message, categories: null })
            })
    }
    render() {
        const { classes } = this.props;

        return (
        <div id="maindiv" className="container-fluid p-0">
            <div className={classes.root}>
                <AppBar position='static'>
                    <Tabs
                        value={this.state.value}
                        onChange={this.handleChange}
                        centered
                        textColor="white"
                        variant="fullWidth"
                    >
                        {
                            this.state.categories.map(category => <Tab label={category} />)
                        }
                    </Tabs>
                </AppBar>
                {this.state.value !==0&&this.state.value !==1&&this.state.value !==2&&this.state.value !==3 && <CarouselPage/>}
                {this.state.value === 0 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 1 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 2 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 3 && <ViewProducts category={this.state.categories[this.state.value]} />}
            </div>
            </div>
        );
    }
}


export default withStyles(styles)(Category)