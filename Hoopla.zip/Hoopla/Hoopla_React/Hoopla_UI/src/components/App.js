import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch,Link } from 'react-router-dom';
import { Redirect } from "react-router-dom";
import './App.css';
import Login from "./Login";
import Register from "./Register";
import CategoryTabComponent from './Category';
import ViewProducts from './ViewProducts';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import ViewProductDetails from './ViewProductDetails';
import SearchBar from "material-ui-search-bar";
import LockIcon from '@material-ui/icons/Lock';
import PersonAddSharpIcon from '@material-ui/icons/PersonAddSharp';
import ViewCart from './ViewCart';
import ViewOrders from './ViewOrders';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import FolderSpecialIcon from '@material-ui/icons/FolderSpecial';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Tooltip from '@material-ui/core/Tooltip';

class App extends Component {
  constructor() {
    super()
    this.state = {
        search: '',
      viewProducts:false,
    }
  }
  logout=()=>
  {
    sessionStorage.clear();
    window.location.reload();
  }
  render() {
    return (
      <div>
        <Router>
          <Fragment>
            <div style={{ marginBottom: '4.2%' }}>
              <React.Fragment >
                <AppBar>
                  <Toolbar>
                    <Typography variant="h6" noWrap >
                      <Link className='text-white' to='/' exact={"true"}>Hoopla</Link>
                    </Typography>&nbsp;&nbsp;

                    <SearchBar
                      style={{color:"secondary"}}
                      value={this.state.search}
                      onChange={(newValue) => {this.setState({ search: newValue });console.log(this.state.search)}}
                      onRequestSearch={() => {this.setState({viewProducts:true}); console.log(this.state.viewProducts);}}
                    />
                     {
                       this.state.search&&this.state.viewProducts?
                       <Redirect to="/viewProducts" />
                       :
                       <Redirect to="/" />
                     }
                    
                    {
                      sessionStorage.getItem('uEmail') === null ?
                      <div className='ml-auto'>
                        <Tooltip title="Login" placement="bottom"><Link className="  ml-auto text-white" to="/login" ><LockIcon/></Link></Tooltip>&nbsp;&nbsp;&nbsp;
                        <Tooltip title="Register" placement="bottom"><Link className=" ml-auto text-white" to="/register" ><PersonAddSharpIcon title="Register"/></Link></Tooltip>
                        </div>
                        :
                        <div className='ml-auto'>
                            <span className='text-capitalize font-weight-bold font-italic'>Welcome&nbsp;{sessionStorage.getItem('uName')}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <Tooltip title="Register" placement="bottom"><Link to="/viewCart"><ShoppingCartIcon style={{ color:"white" }}/></Link></Tooltip>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Tooltip title="Register" placement="bottom"><Link to="/viewOrders"><FolderSpecialIcon style={{ color: "white" }}/></Link></Tooltip>&nbsp;&nbsp;
                          <button type='button'onClick={this.logout} className='btn'><ExitToAppIcon style={{ color: "white" }}/></button>
                        </div>
                    }
                  </Toolbar>
                </AppBar>
              </React.Fragment>
            </div>
            <Switch>
              <Route exact path='/dashboard' component={()=><CategoryTabComponent key={Date.now()}/>} />
              <Route exact path='/login' component={() => <Login />} />
              <Route exact path='/register' component={() => <Register />} />
              <Route exact path='/viewProducts' component={() => <ViewProducts search={this.state.search} />} />
              <Route exact path='/viewProductDetails/:_id' component={({ match }) => <ViewProductDetails match={match} />} />
              <Route exact path='/viewOrders' component={()=> <ViewOrders/>}/>
              <Route exact path='/viewCart' component={()=> <ViewCart/>}/>
              <Route exact path='/' component={()=><CategoryTabComponent key={Date.now()}/>} />              
            </Switch>
          </Fragment>
        </Router>
      </div>
    );
  }
}

export default App