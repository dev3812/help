
import React, { Component } from 'react'
import axios from 'axios'
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';
import { Link } from 'react-router-dom';
import "./ViewProducts.css";
import StarIcon from '@material-ui/icons/Star';

const backendUrl = 'http://localhost:2000/product/getProducts/'

const useStyles = makeStyles((theme) => ({
    root: {
        maxWidth: 245,
        flexGrow: 1,
        display: 'flex',
        '& > * + *': {
            marginLeft: theme.spacing(2),
        },
    },
}));

export class ProductList extends Component {

    constructor(props) {
        super(props)

        this.state = {
            productsArray: [],
            errorMessage: "",
            // raised:false
        }
    }

    componentDidMount() {
        if (this.props.category !== undefined) {
            axios.get(`${backendUrl}${this.props.category}`).then(response => {
                this.setState({ productsArray: response.data })
            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message })
                } else {
                    this.setState({ errorMessage: error.message })
                }
            })

        }
        else if (this.props.search !== undefined) {
            axios.get(`http://localhost:2000/product/search/${this.props.search}`).then(response => {
                this.setState({ productsArray: response.data })
            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message })
                } else {
                    this.setState({ errorMessage: error.message })
                }
            })

        }
    }


    // toggleRaised = () => this.setState({raised:!this.state.raised});

    render() {
        const { classes } = this.props;
        return (
            <div className="mt-5" style={{ marginLeft: '2%',marginRight:'2%' }}>
                <Grid container spacing={2}>
                    {
                        this.state.productsArray ? this.state.productsArray.map((product, index) => {
                            return (

                                <Grid item xs={6} sm={3} md={3} lg={3} key={index} >
                                    <Card 
                                        // onMouseOver={()=>this.toggleRaised()}
                                        // onMouseOut={()=>this.toggleRaised()}
                                        // raised={this.state.raised}
                                        className={classes.root} id="card" style={{
                                        display: 'block',
                                        width: '350px',
                                        height: "350px"
                                    }}>
                                        <Link to={`/viewProductDetails/${product._id}`}  >
                                            <CardActionArea >
                                                <img className="names" src={require(`../assets/img/${product.image}`)} alt={product.pName}  />
                                            </CardActionArea>
                                        </Link>
                                        <CardContent>
                                                    <p className='badge badge-danger float-right'>{product.pRating}<StarIcon style={{fontSize:"1rem",marginTop:-4}}/></p><br/>
                                                    <p className="container-fluid"><p className="row"><p className="col-md-9 text-left">{product.pName}</p><p className="col-md-3 text-right">₹{product.price}</p></p></p>
                                                </CardContent>
                                    </Card>
                                </Grid>
                            )


                        }) : <CircularProgress />
                    }


                </Grid>
            </div>
        )
    }
}

export default withStyles(useStyles)(ProductList);
